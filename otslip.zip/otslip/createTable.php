<?php

include 'dbconn.php';

$servername = "localhost";
$username = "root";
$password = "";
$db = "otslipdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// // Create table EmpDetails
// $sql = "CREATE TABLE EmpDetails (
// 		empID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
// 		empName VARCHAR(100) NOT NULL,
// 		dateFiled DATE NOT NULL,
// 		perCoveredFrom DATE NOT NULL,
// 		perCoveredTo DATE NOT NULL,
// 		imSupervisor VARCHAR(100) NOT NULL,
// 		otdate DATE NOT NULL,
// 		timeIn VARCHAR(50) NOT NULL,
// 		timeOut VARCHAR(50) NOT NULL,
// 		noOfHrs INT NOT NULL,
// 		remarks VARCHAR(500) NOT NULL,
// 		totalOT INT NOT NULL)";

	// Create table OTDetails
$sql = "CREATE TABLE OTDetails (
		empID INT NOT NULL,
		ot_date DATE NOT NULL,
		time_in INT NOT NULL,
		time_out INT NOT NULL,
		noOf_hrs INT NOT NULL,
		remarks VARCHAR(500) NOT NULL,
		total_OT VARCHAR(500) NOT NULL";

if ($conn->query($sql) === TRUE) {
    echo "OTDetails table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>