<?php

session_start();

$sessions = ['login','user_id'];

foreach ($sessions as $key => $value) {
	if(isset($_SESSION[$value]))
		unset($_SESSION[$value]);
}
session_destroy();
header('location: login.php');