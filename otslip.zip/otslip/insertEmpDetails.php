<?php
	include 'dbconn.php';


	// $time1 =strtotime($timeIn);
	// $time2 = strtotime($timeOut);
 //  	$diff = $time2 - $time1;
 // 	echo  date('H:i:s', $diff)

	// setlocale(LC_TIME, "fi_FI");
	// $p = string strftime("%p,");	




	// $empName = $_POST['empName'];
	// $dateFiled = $_POST['dateFiled'];
	// $perCoveredFrom = $_POST['perCoveredFrom'];
	// $perCoveredTo = $_POST['perCoveredTo'];
	// $ImSupervisor = $_POST['ImSupervisor'];

	$otdate = $_POST['otdate'];
	$timeIn = $_POST['timeIn'];
	$timeOut = $_POST['timeOut'];
	$noOfHrs = $_POST['noOfHrs'];
	$remarks = $_POST['remarks'];
	$totalOT = $_POST['totalOT'];
	$records = $_POST['records'];

	// $timeIn = 0;
	// if($timeIn != 0){
	// 	if($conn->query("INSERT INTO empDetails 
	// 		VAlUES ('','$empName',Now(),'$perCoveredFrom','$perCoveredTo','$ImSupervisor', '$otdate', '$timeIn',
	// 		'$timeOut', '$noOfHrs', '$remarks', '$totalOT')"))
	// }

	// $details = array ('otdate','timeIn','timeOut','noOfHrs','remarks','totalOT');
	// $arraylength = count($details);

	// for($x = 0; $x < $arraylength; $x++){
	// 	if($conn->query("INSERT INTO OTDetails VALUES ('','$otdate','$timeIn','$timeOut','$noOfHrs','$remarks','$totalOT')")){
	// 		echo "okay?message=okay";
	// 	}else{
	// 		echo "error".$conn->error;
	// 	}
	// }


if(is_array($records)){
 
    $DataArr = array();
    foreach($records as $row){
        $otdate = mysql_real_escape_string($records[$row][0]);
        $timeIn = mysql_real_escape_string($records[$row][1]);
        $timeOut = mysql_real_escape_string($records[$row][2]);
        $timeOut = mysql_real_escape_string($records[$row][3]);
        $noOfHrs = mysql_real_escape_string($records[$row][4]);
        $remarks = mysql_real_escape_string($records[$row][5]);
        $totalOT = mysql_real_escape_string($records[$row][6]);
 
        $DataArr[] = "('$otdate', '$timeIn', '$timeOut','$noOfHrs','$remarks','$totalOT')";
    }
 
    $sql = "INSERT INTO OTDetails ('',otdate, timeIn, timeOut,noOfHrs,remarks,totalOT) values ";
    $sql .= implode(',', $DataArr);
 
    mysqli_query($conn, $query); 
}


	// if($conn->query("INSERT INTO empDetails VAlUES ('','$empName',Now(),'$perCoveredFrom','$perCoveredTo','$ImSupervisor')")){
		
	// }else{
	// 	echo "error occured:" .$conn->error;
	// }
?>