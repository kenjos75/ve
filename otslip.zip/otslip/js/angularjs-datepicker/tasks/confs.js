/*global module*/
(function setUp(module) {
  'use strict';

  module.exports = {
    'dist': 'dist',
    'css': 'src/css',
    'js': 'src/js',
    'serverPort': 8000
  };
}(module));
