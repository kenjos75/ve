var app = angular.module('otslip',['720kb.datepicker']);

app.controller("OtController",function ($scope, $http, $timeout, $interval) {

	//global variables goes here
	$scope.dateFilled = "";
	$scope.current_id = 1;
	$scope.total_records = 0;
    $scope.records = [{date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 1,hours: 0,minutes: 0}];
    $scope.totalOvertime = 0;
    $scope.totalHours = 0;
    $scope.totalMinutes = 0;
    $scope.submit_value = 'Submit';
    $scope.perCoveredFrom = "";
    $scope.perCoveredTo = "";
    $scope.employee_id = 0;
    $scope.supervisor_id = 0;

	//set current date
	getCurrentDate();

	//private functions goes here
	function getCurrentDate(){
		$http.get('request.php?request=get-current-date')
		.then(function(response){
			$scope.dateFilled = new Date(response.data);
		});
	}



	function calculateTotal(){
		var total = 0;
    	var totalHours = 0;
    	var totalMinutes = 0;
    	angular.forEach($scope.records,function(value, key) {
    		if(value.no_of_hours!='')
    		{
    			totalHours = eval(totalHours + parseInt(value.hours));
    			totalMinutes = eval(totalMinutes + parseInt(value.minutes));
    		}
		});
        console.log($scope.dateFilled);

    	var concat_hours = (totalHours>1) ? totalHours + ' hours': totalHours + ' hour';
		var concat_minutes = (totalMinutes>1) ? totalMinutes + ' minutes': totalMinutes + ' minute';
    	$scope.totalOvertime = concat_hours + ' and ' + concat_minutes;
	}
	//submit the form
	$scope.submit = function(){

		var employee_id = parseInt(jQuery('#employee_id').val());
    	var supervisor_id = parseInt(jQuery('#supervisor_id').val());

		var req = {
			method: "POST",
			url: "request.php",
			headers: {
			   "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
			},
			data: $.param({request: "insert-overtime-record",records: $scope.records,date_filed: $scope.dateFilled,employee_id: employee_id,period_from: $scope.perCoveredFrom,period_to: $scope.perCoveredTo,total_overtime: $scope.totalOvertime,supervisor_id: supervisor_id})
		};

		$scope.submit_value = 'Submitting...';
    	$http(req).then(function(response){
    		response = response.data;
    		$scope.submit_value = "Submit";
    		if(response.status=="ok")
    		{
    			alert("Overtime Slip successfully inserted.");
    			jQuery('#add_details')[0].reset();
    		}
    	});
        
        console.log({request: "insert-overtime-record",records: $scope.records,date_filed: $scope.dateFilled,employee_id: employee_id,period_from: $scope.perCoveredFrom,period_to: $scope.perCoveredTo,total_overtime: $scope.totalOvertime,supervisor_id: supervisor_id});

    }


	//add new row to the table
    $scope.addMore = function (){
    	
    	$scope.current_id++;
    	$scope.records.push({date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 0,hours: 0,minutes: 0});
        $scope.total_records++;
    }

    //calculate
    $scope.calculate = function(record){

	  	// Create the date instances
	   	var timeStart = new Date("01/01/2018 " + record.time_in);
	  	var timeEnd = new Date("01/01/2018  " + record.time_out);
	  	var hourDiff = timeEnd - timeStart;
	  	var secDiff = hourDiff / 1000;
	  	var minDiff = hourDiff / 60 / 1000;
	  	var hDiff = hourDiff / 3600 / 1000;
	  	var humanReadable = {};
		humanReadable.hours = Math.floor(hDiff);
		humanReadable.minutes = minDiff - 60 * humanReadable.hours;

		var concat_hours = (humanReadable.hours>1) ? humanReadable.hours + ' hours': humanReadable.hours + ' hour';
		var concat_minutes = (humanReadable.minutes>1) ? humanReadable.minutes + ' minutes': humanReadable.minutes + ' minute';
		record.no_of_hours = concat_hours + ' and ' + concat_minutes; 
    	record.hours = humanReadable.hours;
    	record.minutes = humanReadable.minutes;
    	calculateTotal();

    }

    $scope.removeRow = function(index){
    	
    	if($scope.total_records!=0)
    	{
    		$scope.current_id--;
    		$scope.records.splice(index, 1);
    		$scope.total_records--;
    		calculateTotal();
    	}
    }

});