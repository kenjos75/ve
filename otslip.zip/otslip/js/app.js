var app = angular.module('otslip',['720kb.datepicker','angular-click-outside']);

app.controller("OtController",function ($scope, $http, $timeout, $interval) {

	//global variables goes here
	$scope.dateFilled = "";
	$scope.current_id = 1;
	$scope.total_records = 0;
    $scope.records = [{final_date: '',date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 1,hours: 0,minutes: 0}];
    $scope.totalOvertime = 0;
    $scope.totalHours = 0;
    $scope.totalMinutes = 0;
    $scope.submit_value = 'Submit';
    $scope.perCoveredFrom = "";
    $scope.perCoveredTo = "";
    $scope.employee_id = 0;
    $scope.supervisor_id = 0;

    $scope.employees_supervisors = [];
    $scope.employees_supervisors_ids = [];
    $scope.employees_commons = [];
    $scope.employees_commons_ids = [];
    
    $scope.employee_model = {fill_state: 0};
    $scope.supervisor_model = {fill_state: 0};

    $scope.employee_model_id = 0;
    $scope.supervisor_model_id = 0;

	//set current date
	getCurrentDate();

    //load all employees
    getEmployees();

	//private functions goes here
	function getCurrentDate(){

		$http.get('request.php?request=get-current-date')
		.then(function(response){
			$scope.dateFilled = new Date(response.data);
		});

	}

    function getEmployees(){

        $http.get('request.php?request=get-employees')
        .then(function(response){
            if(response.data.status=='ok'){
               angular.forEach(response.data.employees,function(value, key){
                    if(value.type==1)
                    {
                        $scope.employees_supervisors.push(value.text);
                        $scope.employees_supervisors_ids.push(value.id);
                    }
                    else
                    {
                        $scope.employees_commons.push(value.text);
                        $scope.employees_commons_ids.push(value.id);
                    }
               });
            }
        });

    }

	function calculateTotal(){
		var total = 0;
    	var totalHours = 0;
    	var totalMinutes = 0;
    	angular.forEach($scope.records,function(value, key) {
    		if(value.no_of_hours!='')
    		{
    			totalHours = eval(totalHours + parseInt(value.hours));
    			totalMinutes = eval(totalMinutes + parseInt(value.minutes));
    		}
		});
       
    	var concat_hours = (totalHours>1) ? totalHours + ' hours': totalHours + ' hour';
		var concat_minutes = (totalMinutes>1) ? totalMinutes + ' minutes': totalMinutes + ' minute';
    	$scope.totalOvertime = concat_hours + ' and ' + concat_minutes;
	}


    $scope.closeEmployee = function(){
        $scope.employee_model.fill_state=0;
        //$scope.employee_model_id = 0;
    }


    $scope.closeSupervisor = function(){
        $scope.supervisor_model.fill_state=0;
        //$scope.supervisor_model_id = 0;
    }

    $scope.setEmployee = function(employee,key) {
        $scope.employee_fill = employee;
        $scope.employee_model.fill_state = 0;
        $scope.employee_model_id = $scope.employees_commons_ids[key];
    }


    $scope.setSupervisor = function(employee,key) {
        $scope.supervisor_fill = employee;
        $scope.supervisor_model.fill_state = 0;
        $scope.supervisor_model_id = $scope.employees_supervisors_ids[key];
    }

    $scope.searchSupervisor = function(){
        $scope.supervisor_model.fill_state = ($scope.supervisor_fill!='') ? 1 : 0;
        if($scope.supervisor_model.fill_state==0)
            $scope.supervisor_model_id = 0;
    }

    $scope.searchEmployee = function(){
        $scope.employee_model.fill_state = ($scope.employee_fill!='') ? 1 : 0;
        if($scope.employee_model.fill_state==0)
            $scope.employee_model_id = 0;
    }

	//submit the form
	$scope.submit = function(){

        var employee_id = parseInt($scope.employee_model_id);
        var supervisor_id = parseInt($scope.supervisor_model_id);

        if($scope.employees_commons.indexOf($scope.employee_fill)==-1)
            employee_id = 0;

        if($scope.employees_supervisors.indexOf($scope.supervisor_fill)==-1)
            employee_id = 0;

        
        var dateFilled = $scope.dateFilled.getFullYear() + '-' + eval($scope.dateFilled.getMonth() + 1) + '-' + $scope.dateFilled.getDate();   
        var perCoveredTo = $scope.perCoveredTo.getFullYear() + '-' + eval($scope.perCoveredTo.getMonth() + 1) + '-' + $scope.perCoveredTo.getDate();
        var perCoveredFrom = $scope.perCoveredFrom.getFullYear() + '-' + eval($scope.perCoveredFrom.getMonth() + 1) + '-' + $scope.perCoveredFrom.getDate();

        angular.forEach($scope.records,function(value, key) {
            $scope.records[key].final_date =value.date.getFullYear() + '-' + eval(value.date.getMonth() + 1) + '-' + value.date.getDate();
        });

        var req = {
            method: "POST",
            url: "request.php",
            headers: {
               "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
            },
            data: $.param({request: "insert-overtime-record",records: $scope.records,date_filled: dateFilled,employee_id: employee_id,period_from: perCoveredFrom,period_to: perCoveredTo,total_overtime: $scope.totalOvertime,supervisor_id: supervisor_id,employee_name: $scope.employee_fill,supervisor_name: $scope.supervisor_fill})
        };

        $scope.submit_value = 'Submitting...';

        $http(req).then(function(response){
            response = response.data;
            $scope.submit_value = "Submit";
            if(response.status=="ok")
            {
                alert("Overtime Slip successfully inserted.");
                
                //jQuery('#add_details')[0].reset();
                $timeout(function(){
                    window.location.reload();
                },2000);

            }
        });
    }


    $scope.resetForm = function(form) {
      //Even when you use form = {} it does not work
      angular.copy({},form);
    }



	//add new row to the table
    $scope.addMore = function (){
    	
    	$scope.current_id++;
    	$scope.records.push({final_date: '',date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 0,hours: 0,minutes: 0});
        $scope.total_records++;
    }

    //calculate
    $scope.calculate = function(record){

	  	// Create the date instances
	   	var timeStart = new Date("01/01/2018 " + record.time_in);
	  	var timeEnd = new Date("01/01/2018  " + record.time_out);
	  	var hourDiff = timeEnd - timeStart;
	  	var secDiff = hourDiff / 1000;
	  	var minDiff = hourDiff / 60 / 1000;
	  	var hDiff = hourDiff / 3600 / 1000;
	  	var humanReadable = {};
		humanReadable.hours = Math.floor(hDiff);
		humanReadable.minutes = minDiff - 60 * humanReadable.hours;

		var concat_hours = (humanReadable.hours>1) ? humanReadable.hours + ' hours': humanReadable.hours + ' hour';
		var concat_minutes = (humanReadable.minutes>1) ? humanReadable.minutes + ' minutes': humanReadable.minutes + ' minute';
		record.no_of_hours = concat_hours + ' and ' + concat_minutes; 
    	record.hours = humanReadable.hours;
    	record.minutes = humanReadable.minutes;
    	calculateTotal();

    }

    $scope.removeRow = function(index){
    	
    	if($scope.total_records!=0)
    	{
    		$scope.current_id--;
    		$scope.records.splice(index, 1);
    		$scope.total_records--;
    		calculateTotal();
    	}
    }

});