var app = angular.module('otslip',['720kb.datepicker','angular-click-outside']);

app
.directive('times',function(){
  return {
    templateUrl: 'timeoptions.html'
  };
})
.controller("OtController",function ($scope, $http, $timeout, $interval) {

    $scope.timeOptions = ['00:00','00:30','01:00','01:30','02:00','02:30','03:00','03:30','04:00','04:30','05:00','05:30','06:00','06:30','07:00','07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00','22:30','23:00','23:30',
    ];

	//global variables goes here
	$scope.dateFilled = "";
	$scope.current_id = 1;
	$scope.total_records = 0;
    $scope.records = [{final_date: '',date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 1,hours: 0,minutes: 0}];
    $scope.totalOvertime = 0;
    $scope.totalHours = 0;
    $scope.totalMinutes = 0;
    $scope.submit_value = 'Submit';
    $scope.perCoveredFrom = "";
    $scope.perCoveredTo = "";
    $scope.employee_id = 0;
    $scope.supervisor_id = 0;

    $scope.employees_supervisors = [];
    $scope.employees_supervisors_ids = [];
    $scope.employees_commons = [];
    $scope.employees_commons_ids = [];
    
    $scope.employee_model = {fill_state: 0};
    $scope.supervisor_model = {fill_state: 0};

    $scope.employee_model_id = 0;
    $scope.supervisor_model_id = 0;

	//set current date
	getCurrentDate();

    //load all employees
    getEmployees();

	//private functions goes here
	function getCurrentDate(){

		$http.get('request.php?request=get-current-date')
		.then(function(response){
			$scope.dateFilled = new Date(response.data);
		});

	}



    function createSpaces(len){

        var createSpacesNow = '';
        for(var x=0;x<len;x++){
            createSpaces +=' ';
        }
        return createSpacesNow;
    }
    function getEmployees(){

        $http.get('request.php?request=get-employees')
        .then(function(response){
            if(response.data.status=='ok'){
               angular.forEach(response.data.employees,function(value, key){
                    if(value.type==1)
                    {
                        $scope.employees_supervisors.push(value.text);
                        $scope.employees_supervisors_ids.push(value.id);
                    }
                    else
                    {
                        $scope.employees_commons.push(value.text);
                        $scope.employees_commons_ids.push(value.id);
                    }
               });
            }
        });

    }

	function calculateTotal(){
		var total = 0;
    	var totalHours = 0;
    	var totalMinutes = 0;
    	angular.forEach($scope.records,function(value, key) {
    		if(value.no_of_hours!='')
    		{
    			totalHours = eval(totalHours + parseInt(value.hours));
    			totalMinutes = eval(totalMinutes + parseInt(value.minutes));
    		}
		});
       
    	var concat_hours = (totalHours>1) ? totalHours + ' hours': totalHours + ' hour';
		var concat_minutes = (totalMinutes>1) ? totalMinutes + ' minutes': totalMinutes + ' minute';
    	$scope.totalOvertime = concat_hours + ' and ' + concat_minutes;
	}


    $scope.closeEmployee = function(){
        $scope.employee_model.fill_state=0;
        //$scope.employee_model_id = 0;
    }


    $scope.closeSupervisor = function(){
        $scope.supervisor_model.fill_state=0;
        //$scope.supervisor_model_id = 0;
    }

    $scope.setEmployee = function(employee,key) {
        $scope.employee_fill = employee;
        $scope.employee_model.fill_state = 0;
        $scope.employee_model_id = $scope.employees_commons_ids[key];
    }


    $scope.setSupervisor = function(employee,key) {
        $scope.supervisor_fill = employee;
        $scope.supervisor_model.fill_state = 0;
        $scope.supervisor_model_id = $scope.employees_supervisors_ids[key];
    }

    $scope.searchSupervisor = function(){
        $scope.supervisor_model.fill_state = ($scope.supervisor_fill!='') ? 1 : 0;
        if($scope.supervisor_model.fill_state==0)
            $scope.supervisor_model_id = 0;
    }

    $scope.searchEmployee = function(){
        $scope.employee_model.fill_state = ($scope.employee_fill!='') ? 1 : 0;
        if($scope.employee_model.fill_state==0)
            $scope.employee_model_id = 0;
    }

	//submit the form
	$scope.submit = function(){

        var employee_id = parseInt($scope.employee_model_id);
        var supervisor_id = parseInt($scope.supervisor_model_id);

        if($scope.employees_commons.indexOf($scope.employee_fill)==-1)
            employee_id = 0;

        if($scope.employees_supervisors.indexOf($scope.supervisor_fill)==-1)
            employee_id = 0;

        
        var dateFilled = $scope.dateFilled.getFullYear() + '-' + eval($scope.dateFilled.getMonth() + 1) + '-' + $scope.dateFilled.getDate();   
        var perCoveredTo = $scope.perCoveredTo.getFullYear() + '-' + eval($scope.perCoveredTo.getMonth() + 1) + '-' + $scope.perCoveredTo.getDate();
        var perCoveredFrom = $scope.perCoveredFrom.getFullYear() + '-' + eval($scope.perCoveredFrom.getMonth() + 1) + '-' + $scope.perCoveredFrom.getDate();

        angular.forEach($scope.records,function(value, key) {
            $scope.records[key].final_date =value.date.getFullYear() + '-' + eval(value.date.getMonth() + 1) + '-' + value.date.getDate();
        });

        var req = {
            method: "POST",
            url: "request.php",
            headers: {
               "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
            },
            data: $.param({request: "insert-overtime-record",records: $scope.records,date_filled: dateFilled,employee_id: employee_id,period_from: perCoveredFrom,period_to: perCoveredTo,total_overtime: $scope.totalOvertime,supervisor_id: supervisor_id,employee_name: $scope.employee_fill,supervisor_name: $scope.supervisor_fill})
        };

        $scope.submit_value = 'Submitting...';


        var df = new Date(dateFilled);
        var dfr = df.toDateString();

        var pf = new Date(perCoveredFrom);
        var pfr = pf.toDateString();

        var pt = new Date(perCoveredTo);
        ptr = pt.toDateString();

        var dynamicContent = [
            {
              columns: [
                {
                  // percentage width
                  width: '60%',
                  text: '',
                  fontSize: 10,
                  margin: [0,0,0,10]
                },
                {
                  // auto-sized columns have their widths based on their content
                  width: '40%',
                  text: 'Period covered from          to',
                  fontSize: 10,
                  margin: [0,0,0,10]
                }
              ]
            },
            {
                columns: [
                    {
                      // percentage width
                      width: '60%',
                      text: 'Date Filled: ' + dfr,
                      fontSize: 10
                    },
                    {
                      // auto-sized columns have their widths based on their content
                      width: '40%',
                      text: pfr + '          ' + ptr,
                      fontSize: 10
                    }
                ]
            },
            {
                columns: [
                    {
                      // percentage width
                      width: '60%',
                      text: 'Name: ' + $scope.employee_fill,
                      fontSize: 10
                    },
                    {
                      // auto-sized columns have their widths based on their content
                      width: '40%',
                      text: 'Supervisor: ' + $scope.supervisor_fill,
                      fontSize: 10
                    }
                ]
            },
            {
                columns: [
                    {
                      // percentage width
                      width: '100%',
                      text: 'Date Time In Time Out No. of Hours Remarks',
                      fontSize: 10,
                      margin: [0,20,0,0]
                    }
                ]
            }
        ];

        angular.forEach($scope.records,function(value, key){
            dynamicContent.push({columns: [{
              // percentage width
              width: '100%',
              text: value.final_date + ' ' + value.time_in + ' ' + value.time_out + ' ' + value.no_of_hours + ' ' + value.remarks,
              fontSize: 10,
              margin: [0,20,0,0]
            }]});
        });

         var docDefinition = {
           content: dynamicContent,
           styles: {
             label: {
               fontSize: 10,
               bold: true
             },
             anotherStyle: {
               italic: true,
               alignment: 'right'
             }
           }
         };


        $http(req).then(function(response){
            response = response.data;
            $scope.submit_value = "Submit";
            if(response.status=="ok")
            {
                pdfMake.createPdf(docDefinition).download('sample.pdf');
                alert("Overtime Slip successfully inserted.");
                
                //jQuery('#add_details')[0].reset();
                $timeout(function(){
                    //window.location.reload();
                },2000);

            }
        });
    }

    $scope.resetForm = function(form) {
      //Even when you use form = {} it does not work
      angular.copy({},form);
    }

	//add new row to the table
    $scope.addMore = function (){
    	
    	$scope.current_id++;
    	$scope.records.push({final_date: '',date: '',id: $scope.current_id,time_in: '',time_out: '',no_of_hours: '',remarks: '',show_add_button: 0,hours: 0,minutes: 0});
        $scope.total_records++;
    }

    //calculate
    $scope.calculate = function(record){

	  	// Create the date instances
	   	var timeStart = new Date("01/01/2018 " + record.time_in);
	  	var timeEnd = new Date("01/01/2018  " + record.time_out);
	  	var hourDiff = timeEnd - timeStart;
	  	var secDiff = hourDiff / 1000;
	  	var minDiff = hourDiff / 60 / 1000;
	  	var hDiff = hourDiff / 3600 / 1000;
	  	var humanReadable = {};
		humanReadable.hours = Math.floor(hDiff);
		humanReadable.minutes = minDiff - 60 * humanReadable.hours;

		var concat_hours = (humanReadable.hours>1) ? humanReadable.hours + ' hours': humanReadable.hours + ' hour';
		var concat_minutes = (humanReadable.minutes>1) ? humanReadable.minutes + ' minutes': humanReadable.minutes + ' minute';
		record.no_of_hours = concat_hours + ' and ' + concat_minutes; 
    	record.hours = humanReadable.hours;
    	record.minutes = humanReadable.minutes;
    	calculateTotal();

    }

    $scope.removeRow = function(index){
    	
    	if($scope.total_records!=0)
    	{
    		$scope.current_id--;
    		$scope.records.splice(index, 1);
    		$scope.total_records--;
    		calculateTotal();
    	}
    }

});