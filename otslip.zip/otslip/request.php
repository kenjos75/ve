<?php
	
	$credentials = ["host"=>"localhost","username"=>"root","password"=>"","database_name"=>"otslipdb"];

	function getCurrentDate(){
		echo date("Y-m-d",time());
	}


	function getEmployees(){

		global $credentials;
		$status = ["status"=>"not ok","employees"=>[],"error_message"=>""];
		
		$mysqli = new mysqli($credentials["host"],$credentials["username"],$credentials["password"],$credentials["database_name"]);
		
		/* check connection */
		if ($mysqli->connect_errno) {
		    $status["error_message"] = "Error in connecting database.";
		}

		$result = $mysqli->query("SELECT * FROM employees");

		if($result){
		     // Cycle through results
		    while ($row = $result->fetch_assoc()){
		        array_push($status["employees"], $row);
		    }
		    // Free result set
		    $result->close();
		    $mysqli->next_result();
			
		    $employees = [];
			foreach ($status["employees"] as $key => $employee) {
				array_push($employees,["id"=>$employee["id"], "text"=>ucwords($employee["first_name"] . " " . $employee["last_name"])]);
			}

			$status["employees"] = $employees;

			$status["status"] = "ok";
		}
		else
			$status["error_message"] = "No result found.";
		
		echo json_encode($status);

	}

	function insertOtDetails(){

		global $credentials;
		$status = ["status"=>"not ok","employees"=>[],"error_message"=>"","date_filled"=>''];
		$mysqli = new mysqli($credentials["host"],$credentials["username"],$credentials["password"],$credentials["database_name"]);
		
		/* check connection */
		if ($mysqli->connect_errno) {
		    $status["error_message"] = "Error in connecting database.";
		}

		if($mysqli->query("INSERT INTO overtime_slips(employee_id,date_filled,covered_from,covered_to,supervisor_id) VALUES(".$_POST["employee_id"].",'".$_POST["date_filled"]."','".$_POST["period_from"]."','".$_POST["period_to"]."',".$_POST["supervisor_id"].")")===TRUE)
		{

			$last_insert_id = $mysqli->insert_id;

			foreach($_POST['records'] as $key=>$value) {
			     $stmt = $mysqli->prepare("INSERT INTO overtime_slip_records(overtime_slip_id,date_slip,time_in,time_out,no_hours,remarks) VALUES (?, ?, ?, ?, ?, ?)");
			     $stmt->bind_param('dsssss', $last_insert_id,$value["final_date"],$value["time_in"],$value["time_out"],$value["no_of_hours"],$value["remarks"]);
			     $stmt->execute();
			     $stmt->close();        
			}
			$status["status"] = "ok";
		}
		else
		{
			$status["error_message"] = "MYSQL Error: "  . $mysqli->error;
		}
		echo json_encode($status);
	}


	if(isset($_POST['request']))
	{
		$request = trim($_POST['request']);

		if($request==="insert-overtime-record")
			insertOtDetails();
	}

	if(isset($_GET['request']))
	{
		$request = trim($_GET['request']);

		if($request==="get-current-date")
			getCurrentDate();
		else if($request=='get-employees')
			getEmployees();

	}

?>