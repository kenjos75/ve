<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <!-- <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script> -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="js/angularjs-datepicker/src/css/angular-datepicker.css" />
		<link rel="stylesheet" type="text/css" href="style.css">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<!-- <script href="js/bootstrap.min.js"></script> -->
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.2/angular.min.js"></script>
		<script type="text/javascript" src="js/angularjs-datepicker/src/js/angular-datepicker.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
		<script type="text/javascript" src="js/app.js"></script>
		<title>Overtime Slip</title>

	</head>
	<body>
		<div class="container" ng-app="otslip">
			<div class="logoutDiv">
				<a href="#" class="btn btn-info btn-lg">
	          	<span class="glyphicon glyphicon-log-out"></span> Log out
	        	</a>	
			</div>
			<div class="above">
				<img src="images/logo.png">
				<h3>OVERTIME AUTHORIZATION SLIP</h3>
			</div>
			<div class="below">
				<div class="form-group" ng-controller="OtController">
					<form name="add_details" id="add_details">  
					    <div class="middle">
							<div class="form-group">	
								<table class="table1" cellpadding="10" >
									<tr>
									    <th><label>Date Filed:</label></th>
									    <th>
			                    			<input type="Date" ng-model="dateFilled" class="form-control" name="dateFiled" value="" disabled>
										</th>
									</tr>
									<tr> 
									    <th><label>Employee Name:</label></th>
									    <th>
									    	<select ng-model="employee_id" class="form-control" id="employee_id" name="employee_id">
			                        		</select>
									    </th>
									 </tr>
								 </table> 
					  		</div>
							<div class="form-group2">
								<table class="table2" cellpadding="10">
									<tr>
									    <th><label></label></th>
									
									    <th>Period Covered from<input type="Date" ng-model="perCoveredFrom" class="form-control" name="perCoveredFrom"></th>
									    <th>to<input type="Date" class="form-control" ng-model="perCoveredTo" name="perCoveredTo"></th>
									</tr>
									<tr> 
										<th></th>
									    <th><label>Immediate Supervisor:</label></th>
									    <th>
									    	 <select ng-model="supervisor_id" class="form-control" id="supervisor_id" name="supervisor_id">
			                        		</select>
									    </th>
									 </tr>
								 </table> 
				  			</div>
						</div>
	                  	<div class="table-responsive">  
	                       <table class="table table-bordered" id="dynamic_field">
	                            <tr>
	                              <td>Date</td>
	                              <td>Time In</td>
	                              <td>Time Out</td>
	                              <td>No. Of Hrs</td>
	                              <td>Remarks</td>
	                              <td></td>
	                            </tr>  
	                            <tr ng-repeat="(index,record) in records">  
	                                <td width="20%">
	                                 	<input type="date" ng-model="record.date" name="otdate[]" class="form-control name_list" />
	                                </td>
	                                <!-- <td><input type="time" name="timein[]" placeholder="Enter your Name" class="form-control name_list" /></td>
	                                <td><input type="time" name="timeout[]" placeholder="Enter your Name" class="form-control name_list" /></td> -->
	                                <td>
	                                 	<select name="schedule_timeIn[]" ng-model="record.time_in" id="schedule_timeIn" class="form-control name_list">
										    <option value="00:00">00:00</option>
										    <option value="00:30">00:30</option>
										    <option value="01:00">01:00</option>
										    <option value="01:30">01:30</option>
										    <option value="02:00">02:00</option>
										    <option value="02:30">02:30</option>
										    <option value="03:00">03:00</option>
										    <option value="03:30">03:30</option>
										    <option value="04:00">04:00</option>
										    <option value="04:30">04:30</option>
										    <option value="05:00">05:00</option>
										    <option value="05:30">05:30</option>
										    <option value="06:00">06:00</option>
										    <option value="06:30">06:30</option>
										    <option value="07:00">07:00</option>
										    <option value="07:30">07:30</option>
										    <option value="08:00">08:00</option>
										    <option value="08:30">08:30</option>
										    <option value="09:00">09:00</option>
										    <option value="09:30">09:30</option>
										    <option value="10:00">10:00</option>
										    <option value="10:30">10:30</option>
										    <option value="11:00">11:00</option>
										    <option value="11:30">11:30</option>
										    <option value="12:00">12:00</option>
										    <option value="12:30">12:30</option>
										    <option value="13:00">13:00</option>
										    <option value="13:30">13:30</option>
										    <option value="14:00">14:00</option>
										    <option value="14:30">14:30</option>
										    <option value="15:00">15:00</option>
										    <option value="15:30">15:30</option>
										    <option value="16:00">16:00</option>
										    <option value="16:30">16:30</option>
										    <option value="17:00">17:00</option>
										    <option value="17:30">17:30</option>
										    <option value="18:00">18:00</option>
										    <option value="18:30">18:30</option>
										    <option value="19:00">19:00</option>
										    <option value="19:30">19:30</option>
										    <option value="20:00">20:00</option>
										    <option value="20:30">20:30</option>
										    <option value="21:00">21:00</option>
										    <option value="21:30">21:30</option>
										    <option value="22:00">22:00</option>
										    <option value="22:30">22:30</option>
										    <option value="23:00">23:00</option>
										    <option value="23:30">23:30</option>
										</select>
									</td>
									<td>
										<select name="schedule_timeOut[]" ng-model="record.time_out" id="schedule_timeOut" class="form-control name_list">
										    <option value="00:00">00:00</option>
										    <option value="00:30">00:30</option>
										    <option value="01:00">01:00</option>
										    <option value="01:30">01:30</option>
										    <option value="02:00">02:00</option>
										    <option value="02:30">02:30</option>
										    <option value="03:00">03:00</option>
										    <option value="03:30">03:30</option>
										    <option value="04:00">04:00</option>
										    <option value="04:30">04:30</option>
										    <option value="05:00">05:00</option>
										    <option value="05:30">05:30</option>
										    <option value="06:00">06:00</option>
										    <option value="06:30">06:30</option>
										    <option value="07:00">07:00</option>
										    <option value="07:30">07:30</option>
										    <option value="08:00">08:00</option>
										    <option value="08:30">08:30</option>
										    <option value="09:00">09:00</option>
										    <option value="09:30">09:30</option>
										    <option value="10:00">10:00</option>
										    <option value="10:30">10:30</option>
										    <option value="11:00">11:00</option>
										    <option value="11:30">11:30</option>
										    <option value="12:00">12:00</option>
										    <option value="12:30">12:30</option>
										    <option value="13:00">13:00</option>
										    <option value="13:30">13:30</option>
										    <option value="14:00">14:00</option>
										    <option value="14:30">14:30</option>
										    <option value="15:00">15:00</option>
										    <option value="15:30">15:30</option>
										    <option value="16:00">16:00</option>
										    <option value="16:30">16:30</option>
										    <option value="17:00">17:00</option>
										    <option value="17:30">17:30</option>
										    <option value="18:00">18:00</option>
										    <option value="18:30">18:30</option>
										    <option value="19:00">19:00</option>
										    <option value="19:30">19:30</option>
										    <option value="20:00">20:00</option>
										    <option value="20:30">20:30</option>
										    <option value="21:00">21:00</option>
										    <option value="21:30">21:30</option>
										    <option value="22:00">22:00</option>
										    <option value="22:30">22:30</option>
										    <option value="23:00">23:00</option>
										    <option value="23:30">23:30</option>
									</select>
									<input id="show-result" type = "button" ng-click="calculate(record)" value = "Calculate" class="form-control">
								</td>
	                            <td width="12%"><input type="text" ng-model="record.no_of_hours" name="noOfHrs[]"  id="noOfHrs" placeholder="hrs" class="form-control name_list" value="0" readonly="readonly" /></td>
	                            <td width="30%"><input ng-model="record.remarks" type="text" name="remarks[]" placeholder="Remarks here....." class="form-control name_listt" /></td> 

	                            <td width="12%" ng-show="record.show_add_button==1"><button type="button" ng-click="addMore()" name="add" id="add" class="btn btn-success">Add More</button></td>
	                            <td width="12%" ng-show="record.show_add_button==0"><button type="button" ng-click="removeRow(index)" name="add" id="add" class="btn btn-danger">X</button></td> 
	                        </tr>  
	                    </table>
	                    <table class="table3" cellpadding="10">
							<tr>
							    <th><label>Total Overtime:</label></th>
							    <th><input type="text" ng-model="totalOvertime" class="form-control" name="totalOT" value="0" readonly="readonly"></th>
							</tr>
						</table>  
	                    <input type="button" name="submit" id="submit" class="btn btn-info" value="{{submit_value}}" ng-click="submit()" />  
	                	</div>  
	            	</form>  
	        	</div>      
			</div>
		</div>
		<script type="text/javascript">
			jQuery(document).ready(function(){

				jQuery.get("request.php?request=get-employees",function(results){
					results = jQuery.parseJSON(results);
					jQuery("#employee_id").select2({data: results.employees});
					jQuery("#supervisor_id").select2({data: results.employees});
				});

			});
		</script>
	</body>
</html>