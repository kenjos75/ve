<?php
	session_start();

	if(!isset($_SESSION['login']))
		header('location:login.php');

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <!-- <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script> -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="js/angularjs-datepicker/src/css/angular-datepicker.css" />
		<link rel="stylesheet" type="text/css" href="style.css">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<!-- <script href="js/bootstrap.min.js"></script> -->
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.2/angular.min.js"></script>
		<script type="text/javascript" src="js/angularjs-datepicker/src/js/angular-datepicker.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
		<script type="text/javascript" src="js/angular-click-outside/clickoutside.directive.js"></script>

		<script src='js/pdfmake/build/pdfmake.min.js'></script>
 		<script src='js/pdfmake/build/vfs_fonts.js'></script>

		<script type="text/javascript" src="js/app.js"></script>
		<title>OT SLIP</title>

	</head>
	<body>
		<div class="container" ng-app="otslip">
			<div class="logoutDiv">
				<a href="logout.php" class="btn btn-info btn-lg">
	          	<span class="glyphicon glyphicon-log-out"></span> Log out
	        	</a>	
			</div>
			<div class="above">
				<img src="images/logo.png">
				<h3>OVERTIME AUTHORIZATION SLIP</h3>
			</div>
			<div class="below">
				<div class="form-group" ng-controller="OtController">
					<form name="add_details" ng-model="addDetails" id="add_details" novalidate>  
					    <div class="middle">
							<div class="form-group">	
								<table class="table1" cellpadding="10" >
									<tr>
									    <th><label>Date Filed:</label></th>
									    <th>
			                    			<input type="Date" ng-model="dateFilled" class="form-control" name="dateFiled" disabled>
										</fth>
									</tr>
									<tr> 
									    <th><label>Employee Name:</label></th>
									    <th>
									    	<input required type="text" ng-keyup="searchEmployee()" ng-model="employee_fill" class="form-control" id="employee_fill" />
									    	<ul class="employee_fill_list suggest_list" ng-show="employee_model.fill_state==1">
									    		<li click-outside="closeEmployee()" ng-click="setEmployee(employee,key)" ng-repeat="(key,employee) in employees_commons | filter:employee_fill">{{employee}}</li>
									    	</ul>
									    	<!--<select ng-model="employee_id" class="form-control" id="employee_id" name="employee_id">
			                        		</select> -->
									    </th>
									 </tr>
								 </table> 
					  		</div>

							<div class="form-group2">
								<table class="table2" cellpadding="10">
									<tr>
									    <th><label></label></th>
									
									    <th>Period Covered from<input required type="Date" ng-model="perCoveredFrom" class="form-control" name="perCoveredFrom"></th>
									    <th>to<input required type="Date" class="form-control" ng-model="perCoveredTo" name="perCoveredTo"></th>
									</tr>
									<tr> 
										<th></th>
									    <th><label>Immediate Supervisor:</label></th>
									    <th>
									    	<input required type="text" ng-keyup="searchSupervisor()" ng-model="supervisor_fill" class="form-control" id="supervisor_fill" />
									    	<ul class="supervisor_fill_list suggest_list" ng-show="supervisor_model.fill_state==1">
									    		<li click-outside="closeSupervisor()" ng-click="setSupervisor(employee,key)" ng-repeat="(key,employee) in employees_supervisors | filter:supervisor_fill">{{employee}}</li>
									    	</ul>
									    </th>
									 </tr>
								 </table> 
				  			</div>
						</div>
	                  	<div class="table-responsive">  
	                       <table class="table table-bordered" id="dynamic_field">
	                            <tr>
	                              <td>Date</td>
	                              <td>Time In</td>
	                              <td>Time Out</td>
	                              <td>No. Of Hrs</td>
	                              <td>Remarks</td>
	                              <td>
	                              </td>
	                            </tr>  
	                            <tr ng-repeat="(index,record) in records">  
	                                <td width="20%">
	                                 	<input type="date" required ng-model="record.date" name="otdate[]" class="form-control name_list" />
	                                </td>
	                                <!-- <td><input type="time" name="timein[]" placeholder="Enter your Name" class="form-control name_list" /></td>
	                                <td><input type="time" name="timeout[]" placeholder="Enter your Name" class="form-control name_list" /></td> -->
	                                <td>
	                                 	<select name="schedule_timeIn[]" required ng-model="record.time_in" id="schedule_timeIn" class="form-control name_list" times>
										</select>
									</td>
									<td>
										<select name="schedule_timeOut[]" required ng-model="record.time_out" id="schedule_timeOut" class="form-control name_list" times>
										</select>
										<input id="show-result" type="button" ng-click="calculate(record)" value = "Calculate" class="form-control">
									</td>
	                            <td width="12%"><input required type="text" ng-model="record.no_of_hours" name="noOfHrs[]"  id="noOfHrs" placeholder="hrs" class="form-control name_list" value="0" readonly="readonly" /></td>
	                            <td width="30%"><input ng-model="record.remarks" type="text" name="remarks[]" placeholder="Remarks here....." class="form-control name_list" /></td> 

	                            <td width="12%" ng-show="record.show_add_button==1"><button type="button" ng-click="addMore()" name="add" id="add" class="btn btn-success">Add More</button></td>
	                            <td width="12%" ng-show="record.show_add_button==0"><button type="button" ng-click="removeRow(index)" name="add" id="add" class="btn btn-danger">X</button></td> 
	                        </tr>  
	                    </table>
	                    <table class="table3" cellpadding="10">
							<tr>
							    <th><label>Total Overtime:</label></th>
							    <th><input type="text" required ng-model="totalOvertime" class="form-control" name="totalOT" value="0" readonly="readonly"></th>
							</tr>
						</table>  
	                    <input type="button" ng-disabled="add_details.$invalid" name="submit" id="submit" class="btn btn-info" value="{{submit_value}}" ng-click="submit()" />  
	                	</div>
	            	</form>  
	        	</div>      
			</div>
		</div>
	</body>
</html>