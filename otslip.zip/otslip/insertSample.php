<?php 
	include 'dbconn.php';

if(isset($_POST["ot_date"]))
{
	$empName = $_POST["empName"];
	$dateFiled = $_POST["dateFiled"];
	$perCoveredFrom = $_POST["perCoveredFrom"];
	$perCoveredTo = $_POST["perCoveredTo"];
	$ImSupervisor = $_POST["ImSupervisor"];
	$totalOT = $_POST["totalOT"];

	$ot_date = $_POST["ot_date"];
	$time_in = $_POST["time_in"];
	$time_out = $_POST["time_out"];
	$noOf_hrs = $_POST["noOf_hrs"];
	$remarks = $_POST["remarks"];
	$query = '';	
 
	 for($count = 0; $count<count($ot_date); $count++)
	 {
	 		// $empName_clean = mysqli_real_escape_string($conn, $empName[$count]);
	 		// $dateFiled_clean = mysqli_real_escape_string($conn, $dateFiled[$count]);
	 		// $perCoveredFrom_clean = mysqli_real_escape_string($conn, $perCoveredFrom[$count]);
	 		// $perCoveredTo_clean = mysqli_real_escape_string($conn, $perCoveredTo[$count]);
	 		// $ImSupervisor_clean = mysqli_real_escape_string($conn, $ImSupervisor[$count]);
		  $ot_date_clean = mysqli_real_escape_string($conn, $ot_date[$count]);
		  $time_in_clean = mysqli_real_escape_string($conn, $time_in[$count]);
		  $time_out_clean = mysqli_real_escape_string($conn, $time_out[$count]);
		  $noOf_hrs_clean = mysqli_real_escape_string($conn, $noOf_hrs[$count]);
		  $remarks_clean = mysqli_real_escape_string($conn, $remarks[$count]);
		  // $totalOT_clean = mysqli_real_escape_string($conn, $totalOT[$count]);
		  

		  if($ot_date_clean != '' && $time_in_clean != '' && $time_out_clean != '' && $noOf_hrs_clean != '' && $remarks_clean != '')
			{
			   $query .= 'INSERT INTO empdetails(empName, dateFiled, perCoveredFrom, perCoveredTo, ImSupervisor, ot_date, time_in, time_out,noOf_hrs, remarks, totalOT)
			   		VALUES ("'.$empName_clean.'", Now(), "'.$perCoveredFrom_clean.'", "'.$perCoveredTo_clean.'", 
			   		"'.$ImSupervisor_clean.'", 
			   		"'.$ot_date_clean.'", "'.$time_in_clean.'", "'.$time_out_clean.'", "'.$noOf_hrs_clean.'", "'.$remarks_clean.'", 
			   		"'.$totalOT_clean.'");
			   ';
			}
	 }


	 // $query .= 'INSERT INTO(ot_date, time_in, time_out,
		// 	   				noOf_hrs, remarks) 
		// 	   				VALUES ("'.$empName.'", "'.$dateFiled.'", "'.$perCoveredFrom.'", "'.$perCoveredTo.'", 
		// 	   				"'.$ImSupervisor.'", "'.$ot_date_clean.'", "'.$time_in_clean.'", "'.$time_out_clean.'", "'.$noOf_hrs_clean.'", "'.$remarks_clean.'", "'.$totalOT.'");
 
  if($query != '')
 {
  if(mysqli_multi_query($conn, $query))
  {
   echo 'Item Data Inserted';
  }
  else
  {
   echo 'Errrrror'.$conn->error;
  }
 }
 else
 {
  echo 'All Fields are Required';
 }
}


?>