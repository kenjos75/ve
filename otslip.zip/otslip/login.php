<?php

session_start();

if(isset($_SESSION['login']))
	header('location: index.php');

$credentials = ['host'=>'localhost','username'=>'root','password'=>'','database_name'=>'otslipdb'];
$mysqli = new mysqli($credentials["host"],$credentials["username"],$credentials["password"],$credentials["database_name"]);
$errors = ['code'=>0,'message'=>'Wrong username or password.'];

/* check connection */
if ($mysqli->connect_errno) {
   echo "Error connecting mysql.";
   exit;
}


if(isset($_POST['submit']))
{
	$username = trim($_POST['username']);
	$password = md5(trim($_POST['password']));

	$user_id = 0;
	if($result = $mysqli->query("SELECT * FROM users WHERE username ='".$username."' AND password='".$password."'")){
		
		if($result->num_rows==1)
		{
			// Cycle through results
		    while ($row = $result->fetch_assoc()){
		       $user_id = $row['id'];
		    }
		    // Free result set
		    $result->close();
		    $mysqli->next_result();
		    $_SESSION['login'] = 1;
		    $_SESSION['user_id'] = $user_id;

		    header('location:index.php');
		}
		else
			$errors['code'] = 1;

	}else
		$errors['code'] = 1;


}
?>
<form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
	Username: <input type="text" name="username" value="" /><br/>
	Password: <input type="password" name="password" value="" /><br/>
	<input type="submit" name="submit" value="Login" /><br/>
	<div style="color:red;">
	<?php if($errors['code']==1) : ?>
	<?= $errors['message']; ?>
	<?php endif; ?>
	</div>
</form>