<?php  
 include 'dbconn.php';

//mao ni ang function
 
 if(isset($_POST["otdate"]))
{
  $empName = $_POST["empName"];
  //$dateFiled = $_POST["dateFiled"];
  $perCoveredFrom = $_POST["perCoveredFrom"];
  $perCoveredTo = $_POST["perCoveredTo"];
  $ImSupervisor = $_POST["ImSupervisor"];
  $totalOT = $_POST["totalOT"];

  $otdate = $_POST["otdate"];
  $schedule_timeIn = $_POST["schedule_timeIn"];
  $schedule_timeOut = $_POST["schedule_timeOut"];
  $noOfHrs = $_POST["noOfHrs"];
  $remarks = $_POST["remarks"];
  $query = '';  
 
   for($count = 0; $count<count($otdate); $count++)
   {
      // $empName_clean = mysqli_real_escape_string($conn, $empName[$count]);
      // $dateFiled_clean = mysqli_real_escape_string($conn, $dateFiled[$count]);
      // $perCoveredFrom_clean = mysqli_real_escape_string($conn, $perCoveredFrom[$count]);
      // $perCoveredTo_clean = mysqli_real_escape_string($conn, $perCoveredTo[$count]);
      // $ImSupervisor_clean = mysqli_real_escape_string($conn, $ImSupervisor[$count]);
      $ot_date = mysqli_real_escape_string($conn, $otdate[$count]);
      $time_in= mysqli_real_escape_string($conn, $schedule_timeIn[$count]);
      $time_out = mysqli_real_escape_string($conn, $schedule_timeOut[$count]);
      $noOf_hrs = mysqli_real_escape_string($conn, $noOfHrs[$count]);
      $remarkss = mysqli_real_escape_string($conn, $remarks[$count]);
      // $totalOT_clean = mysqli_real_escape_string($conn, $totalOT[$count]);
      

      if($ot_date != '' && $time_in != '' && $time_out != '' && $noOf_hrs != '' && $remarkss != '')
      {
         $query .= 'INSERT INTO empdetails(empName, dateFiled, perCoveredFrom, perCoveredTo,imSupervisor, ot_date, time_in, time_out, noOf_hrs, remarks, total_OT)
            VALUES ("'.$empName.'", Now(), "'.$perCoveredFrom.'", "'.$perCoveredTo.'", "'.$ImSupervisor.'", "'.$ot_date.'", "'.$time_in.'", "'.$time_out.'", "'.$noOf_hrs.'", "'.$remarkss.'", "'.$totalOT.'");
         ';
      }
   }


   // $query .= 'INSERT INTO(ot_date, time_in, time_out,
    //            noOf_hrs, remarks) 
    //            VALUES ("'.$empName.'", "'.$dateFiled.'", "'.$perCoveredFrom.'", "'.$perCoveredTo.'", 
    //            "'.$ImSupervisor.'", "'.$ot_date_clean.'", "'.$time_in_clean.'", "'.$time_out_clean.'", "'.$noOf_hrs_clean.'", "'.$remarks_clean.'", "'.$totalOT.'");
 
  if($query != '')
 {
  if(mysqli_multi_query($conn, $query))
  {
   echo 'Item Data Inserted';
  }
  else
  {
   echo 'Errrrror'.$conn->error;
  }
 }
 else
 {
  echo 'All Fields are Required';
 }
}

 // $number = count($_POST["otdate"]);  
 // if($number > 0)  
 // {  
 //      for($i=0; $i<$number; $i++)  
 //      {  
 //           if(trim($_POST["details"][$i] != ''))  
 //           {  
 //                $sql = "INSERT INTO sample(details) VALUES('".mysqli_real_escape_string($conn, $_POST["details"][$i])."')";  
 //                mysqli_query($conn, $sql);  
 //           }  
 //      }  
 //      echo "Data Inserted";  
 // }  
 // else  
 // {  
 //      echo "Please Enter Name";  
 // }  


// //calculate time
// if(isset($_POST['show-result'])){
// $timeStart = $_POST['schedule_timeIn'];
// $timeEnd = $_POST['schedule_timeOut'];
// $hrs = $_POST['noOfHrs'];



// $start = new Date('01/01/2018' + $timeStart);
// $end = new Date('01/01/2018' + $end);
// $hrs = $start->diff($end);

// print $hrs->format("%H:%I");
// }
 ?> 


 
   